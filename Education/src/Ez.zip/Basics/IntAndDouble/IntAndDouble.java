package Basics.IntAndDouble;

public class IntAndDouble {
    public static void main(String[] args) {
        int i1 = 3;
        int i2 = 2;
        double d1 = 3;
        double d2 = 2;
        System.out.println("Int 3 / 2 = " + (i1 / i2));
        System.out.println("Double 3 / 2 = " + (d1 / d2));
    }
}
