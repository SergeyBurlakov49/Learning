package Basics.MoonWeight;

public class EarthToMoonWeight {
    public static double getMoonWeight (double EarthWeight){
        return EarthWeight * 0.17;
    }
}
