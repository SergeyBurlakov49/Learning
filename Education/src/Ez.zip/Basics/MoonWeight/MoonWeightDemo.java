package Basics.MoonWeight;

public class MoonWeightDemo {
    public static void main(String[] args) {
        System.out.println("На земле мой вес составляет 55 кг, а на луне он составит " +
                           EarthToMoonWeight.getMoonWeight(55) + " кг. Жаль," +
                           " что немногие знают, что вес измеряется в ньютонах, а не " +
                           "в килограмах, и то, что это сила, с которой тело воздействует" +
                           " на поверхность, к которой притягивается из-за гравитации... ");
    }
}
