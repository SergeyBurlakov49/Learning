package Basics.For;

public class For {
    public static void main(String[] args) {
        for (int i = 0; i < 100; i++){
            System.out.println("Что я делаю...");
        }
    }
}
