package Basics.If;
/** Мое ОКР заставляет меня при восстановлении знаний о программировании писать простейшие программы из первых глав
 книги Шилдта, помогите... */
public class If {
    public static void main(String[] args) {
        if (10 > 11) System.out.println("10 > 11");
        if (11 > 10) System.out.println("11 > 10");
        if (10 > 10) System.out.println("10 > 10");
    }
}
