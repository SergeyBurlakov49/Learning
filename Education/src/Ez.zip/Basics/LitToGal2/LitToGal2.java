package Basics.LitToGal2;

public class LitToGal2 {
    public static void main(String[] args) {
        for (int liters = 1; liters <= 100; liters++){
            System.out.println("There is " + (liters / 3.7854) + " gallons in " + liters + " liters...");
            if (liters % 10 == 0) System.out.println();
        }
    }
}
