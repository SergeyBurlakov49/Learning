package Basics.LitToGal;

public class LitToGal {
    public static void main(String[] args) {
        double liters = 1.5;
        double gallons = 1.5 / 3.7854;
        System.out.println("There is " + gallons + " gallons in " + liters + " liters.");
    }
}
