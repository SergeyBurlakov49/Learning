package Basics.Variables;

public class Variables {
    public static void main(String[] args) {
        int a = 1024;
        int b = 2;
        System.out.println("1024 / 2 = " + (a / b));
    }
}
