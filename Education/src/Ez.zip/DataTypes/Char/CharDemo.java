package DataTypes.Char;

public class CharDemo {
    public static void main(String[] args) {
        char ch;
        for (int i = 1; i <= 128; i++){
            ch = (char) i;
            System.out.println(i + " - " + ch);
        }
    }
}
