package DataTypes.TPifagor;

public class TPifagor {

    public static double getHypot(double a, double b){
        return Math.sqrt((a*a)+(b*b));
    }

}
