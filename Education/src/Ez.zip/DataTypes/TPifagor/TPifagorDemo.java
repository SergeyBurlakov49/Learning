package DataTypes.TPifagor;

public class TPifagorDemo {
    public static void main(String[] args) {
        System.out.println("Длина гипотенузы прямоугольного треугольника с длиной катетов 3 и 4 составляет " +
                            TPifagor.getHypot(3,4));
    }
}
